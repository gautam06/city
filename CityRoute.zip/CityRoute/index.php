<?php
$hostname = "localhost";
$username = "root";
$password = "Mtech";
$database = "city_route";

// Create connection
$conn = new mysqli($hostname, $username, $password, $database);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
<html>

<head>
<title>Upload CSV File</title>
<style>
	body{
		background:#005A31;
		color:#FEFEFE; 
	}
</style>
</head>

<body>

<div>

<form name="import" method="post" enctype="multipart/form-data">
Select City File: <input type="file" name="file1" /><br />
Select Route File: <input type="file" name="file2" /><br />
<input type="submit" name="submit" value="Submit" />
</form>
<?php
if(isset($_POST["submit"]))
{
	$file = $_FILES['file1']['tmp_name'];
	$handle = fopen($file, "r");
	$c = 0;
	
	$sql = "delete from  city ";
	
	if ($conn->query($sql) === TRUE) {
		echo "<br />Old records deleted from city table.";
	}
	
	while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
	{
		$city_id = $filesop[0];
		$city_name = $filesop[1];
	
		$sql = "INSERT INTO city(city_id,city_name) VALUES('$city_id','$city_name')";
		
		if ($conn->query($sql) === TRUE) {
			$c = $c + 1;
		} 
	}

	if($c > 0){
		echo "<br />$c Records inserted in city table";
	}
	else{ echo "Sorry! There is some problem."; }
	
	$file = $_FILES['file2']['tmp_name'];
	$handle = fopen($file, "r");
	$c = 0;
	
	$sql = "delete from route";
	
	if ($conn->query($sql) === TRUE) {
		echo "<br />Old records deleted from route table";
	}
	
	while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
	{
		$id = $filesop[0];
		$source = $filesop[1];
		$dest = $filesop[2];
		$time = $filesop[3];
		$cost = $filesop[4];
		$company = $filesop[5];
		
		$sql = "INSERT INTO route(id,source,dest,time,cost,company) VALUES('$id','$source','$dest','$time','$cost','$company')";

		if ($conn->query($sql) === TRUE) {
			$c = $c + 1;
		} 
	}

	if($c > 0){
		echo "<br /> $c records inserted in route table";
	}
	else{ echo "Sorry! There is some problem."; }
	
	header('Location:  check.php');
}

$conn->close();
?>
</div>
</body>
</html>
