<?php
$servername = "localhost";
$username = "root";
$password = "Mtech";
$dbname = "task1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>

<html>
<head>
<script>
	function checkEntry(){
		var source = document.getElementById('source').value;
		var dest = document.getElementById('dest').value;
		
		if(source != dest){
			return true;
		}
		else{
			return false;
		}
	}
</script>
<style>
	body{
		background:#005A31;
		color:#FEFEFE;
	}
</style>
</head>
<body>

<form action="findRoute.php" id="form1" name="form1" method="post" onsubmit="return checkEntry();">

Select Source: <select id="source" name="source">
<?php 
$sql = "select city_name from city";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    
?>
<option value="<?php echo $row['city_name']; ?>"> <?php echo $row['city_name']; ?> </option>
<?php } } ?>

</select>

<br /><br />

Select Destination: <select id="dest" name="dest">
<?php 
$sql = "select city_name from city";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    
?>
<option value="<?php echo $row['city_name']; ?>"> <?php echo $row['city_name']; ?> </option>
<?php } } $conn->close(); ?>

</select>

<br /><br />
<input type="submit" value="submit" />

</form>
</body>
</html>
