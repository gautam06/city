<?php 
$s = $_POST["source"];
$d = $_POST["dest"];

$servername = "localhost";
$username = "root";
$password = "Mtech";
$dbname = "task1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
?>
<html>
<head>
<title>Find Routes</title>
<style>
body{
	background:#4A96AD;
}
.tab_route{
	padding-top:20px;
	color:#FEFEFE;
	font-size:18px;
	font-family:arial narrow;
}
.tab_route th{
	padding:10px;
}
.tab_route .th1{
	background:#005A31;
}
.tab_route .th2{
	background:#C63D0F;
}
.tab_route td{
	padding:10px;
	background:#7E8F7C;
}
.th1, .th2{
	border:15px solid #3B3738; 
	padding:15px;
} 
</style>
</head>
<body>
<table class="tab_route" align="center">
<?php

$sql = "select * from route where source='$s' and dest='$d'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $row = $result->fetch_assoc(); 
    
?>
	<tr><th class="th1" colspan="4">Direct Routes</th></tr>
	<tr class="th1"><th>Direct Route</th><th>Direct Route Time</th><th>Direct Route Cost</th></tr>
  <tr><td><?php echo $row["source"]." ( ".$row["company"]." ) => ".$row["dest"]; ?></td><td align="center"><?php echo $row["time"]; ?></td><td align="center"><?php echo $row["cost"]; ?></td></tr>

<?php    
} 
else { 
	//echo "<font color='red'>Direct Route Not Found</font>"; 
}

// find indirect routes ------------------------------------------------------------------------------

//find source id-----------------------------------

$sql = "select id from route where source ='$s' and dest != '$d' ";

$result = $conn->query($sql);

$sid = 0;

if ($result->num_rows > 0) {
	
	$row = $result->fetch_assoc();	
    	$sid = $row["id"];
} 
else { 
	//echo "<br /><br />Source Id Not Found"; 
}


//find destination id-----------------------------

$sql = "select id from route where dest = '$d' and source != '$s'";

$result = $conn->query($sql);

$did = 0;

if ($result->num_rows > 0) {
	
	$row = $result->fetch_assoc();	
    	$did = $row["id"];
} 
else { 
	//echo "<br /><br />Destination Id Not Found"; 
}

//final query for finding indirect route

$indirect_route="";

$sql = "select source, company from route where id between $sid and $did";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
		
        	$indirect_route = $indirect_route.$row["source"]." ( ".$row["company"]." ) => ";
    
    }
    $indirect_route = $indirect_route.$d;
    
}
else{
	//echo "<br /><br />Indirect routes not found";
}

//find total time of indirect routes-----------------------------------

$sql = "select sum(time) as ir_time, sum(cost) as ir_cost from route where id between $sid and $did";

$result = $conn->query($sql);

$indirect_route_time=0;

$indirect_route_cost=0;

if ($result->num_rows > 0) {
	
	$row = $result->fetch_assoc();

	$indirect_route_time = $row["ir_time"];
	
	$indirect_route_cost = $row["ir_cost"];	

?>

<tr><th class="th2" colspan="5">Indirect Routes</th></tr>
<tr class="th2"><th>Indirect Route</th><th>Indirect Route Time</th><th>Indirect Route Cost</th></tr>
<tr><td><?php echo $indirect_route; ?></td><td align="center"><?php echo $indirect_route_time; ?></td><td align="center"><?php echo $indirect_route_cost; ?></td></tr>
</table>

<?php        
}
else{
	//echo "<br /><br />Indirect route time & cost not found";
}

$conn->close();
?>
</body>
</html>
